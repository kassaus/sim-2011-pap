﻿
var PageName = 'Login';
var PageId = '72ecc15cd0b44ae1ad758b75941d472a'
var PageUrl = 'Login.html'
document.title = 'Login';
var PageNotes = 
{
"pageName":"Login",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '17');
  value = value.replace(/\[\[GenMonth\]\]/g, '10');
  value = value.replace(/\[\[GenMonthName\]\]/g, 'Outubro');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, 'segunda-feira');
  value = value.replace(/\[\[GenYear\]\]/g, '2011');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u3 = document.getElementById('u3');

var u12 = document.getElementById('u12');

var u4 = document.getElementById('u4');
gv_vAlignTable['u4'] = 'top';
var u0 = document.getElementById('u0');

var u8 = document.getElementById('u8');

u8.style.cursor = 'pointer';
if (bIE) u8.attachEvent("onclick", Clicku8);
else u8.addEventListener("click", Clicku8, true);
function Clicku8(e)
{
windowEvent = e;


if (true) {

	NewWindow("recuperarPass.html" + GetQuerystring(), "", "directories=0, height=300, location=0, menubar=0, resizable=0, scrollbars=0, status=0, toolbar=0, width=600", true, 600, 300);

	parent.window.close();

}

}
gv_vAlignTable['u8'] = 'top';
var u10 = document.getElementById('u10');
gv_vAlignTable['u10'] = 'top';
var u5 = document.getElementById('u5');

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u9 = document.getElementById('u9');

u9.style.cursor = 'pointer';
if (bIE) u9.attachEvent("onclick", Clicku9);
else u9.addEventListener("click", Clicku9, true);
function Clicku9(e)
{
windowEvent = e;


if (((GetWidgetFormText('u5')) == ('pppluis@gmail.com')) && ((GetWidgetFormText('u7')) == ('123456'))) {

	parent.window.close();

    var reload = ParentWindowNeedsReload("userHome.html");
	top.opener.window.location.href = "userHome.html" + GetQuerystring();
    if (reload) {
        top.opener.window.location = "resources/reload.html#" + encodeURI(top.opener.window.location.href);
    }

}
else
if (((GetWidgetFormText('u5')) == ('admin@gmail.com')) && ((GetWidgetFormText('u7')) == ('123'))) {

    var reload = ParentWindowNeedsReload("adminHome.html");
	top.opener.window.location.href = "adminHome.html" + GetQuerystring();
    if (reload) {
        top.opener.window.location = "resources/reload.html#" + encodeURI(top.opener.window.location.href);
    }

	parent.window.close();

}
else
if (true) {

	SetPanelState('u12', 'pd0u12','none','',500,'fade','',500);

}

}

var u14 = document.getElementById('u14');
gv_vAlignTable['u14'] = 'center';
var u6 = document.getElementById('u6');
gv_vAlignTable['u6'] = 'top';
var u2 = document.getElementById('u2');
gv_vAlignTable['u2'] = 'top';
var u11 = document.getElementById('u11');

u11.style.cursor = 'pointer';
if (bIE) u11.attachEvent("onclick", Clicku11);
else u11.addEventListener("click", Clicku11, true);
function Clicku11(e)
{
windowEvent = e;


if (true) {

	parent.window.close();

    var reload = ParentWindowNeedsReload("registo.html");
	top.opener.window.location.href = "registo.html" + GetQuerystring();
    if (reload) {
        top.opener.window.location = "resources/reload.html#" + encodeURI(top.opener.window.location.href);
    }

}

}
gv_vAlignTable['u11'] = 'top';
var u13 = document.getElementById('u13');

var u7 = document.getElementById('u7');

if (window.OnLoad) OnLoad();
