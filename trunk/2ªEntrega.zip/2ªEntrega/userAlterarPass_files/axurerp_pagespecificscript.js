﻿
var PageName = 'userAlterarPass';
var PageId = '439eff4e40114e4cb861932310c2a31e'
var PageUrl = 'userAlterarPass.html'
document.title = 'userAlterarPass';
var PageNotes = 
{
"pageName":"userAlterarPass",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '17');
  value = value.replace(/\[\[GenMonth\]\]/g, '10');
  value = value.replace(/\[\[GenMonthName\]\]/g, 'Outubro');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, 'segunda-feira');
  value = value.replace(/\[\[GenYear\]\]/g, '2011');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u3 = document.getElementById('u3');

var u16 = document.getElementById('u16');
gv_vAlignTable['u16'] = 'center';
var u12 = document.getElementById('u12');
gv_vAlignTable['u12'] = 'top';
var u15 = document.getElementById('u15');

var u4 = document.getElementById('u4');
gv_vAlignTable['u4'] = 'top';
var u0 = document.getElementById('u0');

var u8 = document.getElementById('u8');

u8.style.cursor = 'pointer';
if (bIE) u8.attachEvent("onclick", Clicku8);
else u8.addEventListener("click", Clicku8, true);
function Clicku8(e)
{
windowEvent = e;


if (((GetWidgetFormText('u5')) == ('pppluis@gmail.com')) && ((GetWidgetFormText('u7')) == ('123456'))) {

    var reload = ParentWindowNeedsReload("userHome.html");
	top.opener.window.location.href = "userHome.html" + GetQuerystring();
    if (reload) {
        top.opener.window.location = "resources/reload.html#" + encodeURI(top.opener.window.location.href);
    }

	SetPanelState('u14', 'pd0u14','none','',500,'fade','',500);

	SetPanelVisibility('u9','hidden','none',500);

}
else
if (true) {

	SetPanelState('u9', 'pd0u9','none','',500,'fade','',500);

	SetPanelVisibility('u14','hidden','none',500);

}

}

var u10 = document.getElementById('u10');

var u5 = document.getElementById('u5');

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u9 = document.getElementById('u9');

var u14 = document.getElementById('u14');

var u6 = document.getElementById('u6');
gv_vAlignTable['u6'] = 'top';
var u2 = document.getElementById('u2');
gv_vAlignTable['u2'] = 'top';
var u11 = document.getElementById('u11');
gv_vAlignTable['u11'] = 'center';
var u13 = document.getElementById('u13');

var u7 = document.getElementById('u7');

if (window.OnLoad) OnLoad();
